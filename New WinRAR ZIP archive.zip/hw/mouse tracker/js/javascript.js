document.onmousemove = animasyaKuruq;
var colors = ['black'];
function animasyaKuruq (event) {
    var kuruq = document.createElement("div")
    kuruq.setAttribute("class" , "kuruq")
    document.body.appendChild(kuruq)

    kuruq.style.left = event.clientX + "px"
    kuruq.style.top = event.clientY + "px"
    var color =  colors[Math.floor(Math.random() * colors.length)];
    kuruq.style.borderColor = color;
    kuruq.style.transition  = "all 0.9s linear"

    kuruq.style.left = daire.offsetLeft - 400 + 'px';
    kuruq.style.top = daire.offsetTop - 1020 + 'px';
    kuruq.style.width = "200px";
    kuruq.style.height = "500px";
    kuruq.style.borderwidth = "35px"
    kuruq.style.opacity = 0;
}
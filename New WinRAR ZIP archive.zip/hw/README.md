# 04-04-2018-javascript-dom

## Let's code

- https://codepen.io/Squidies/pen/PQxoBq

Bu tetbigde oldugu kimi mouse tracker yaradmaq lazimdir. Amma burda tek daire yaranir siz ise 25 eded yaradacagsiniz ve her birinin rengi ferqli olacaq

## Algoritm

- https://www.hackerrank.com/challenges/plus-minus/problem

## Research

- https://www.ibm.com/developerworks/library/wa-jsdomupdate/

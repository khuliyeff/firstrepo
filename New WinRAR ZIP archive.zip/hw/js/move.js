var blocks=[];
function SelectBox(elem){
	elem.style.background="green";
	blocks.push(elem);

}
function MoveBox(){
	var rightSection=document.querySelector(".right");
	for (var i = 0; i < blocks.length; i++) {
		rightSection.appendChild(blocks[i])
	}
}
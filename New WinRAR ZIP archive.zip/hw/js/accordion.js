var header=document.querySelector(".header")
var blocks=document.querySelectorAll(".block")

check=true;
// header.addEventListener("click",function(){
// 	if(check){
// 		block.style.display="none";
// 		check=false;
// 	}else{
// 		block.style.display="block";
// 		check=true;
// 	}
// })
function Accord(elem){
	for (var i = 0; i < blocks.length; i++) {
		blocks[i].style.display="none";
	}
	
	if(check){
		elem.nextElementSibling.style.display="none"
		check=false;
	}else{
		elem.nextElementSibling.style.display="block"
		check=true;
	}
	
}
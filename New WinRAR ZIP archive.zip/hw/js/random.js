var btn=document.querySelector(".random");
var w = window.innerWidth;
var h = window.innerHeight;
btn.addEventListener("click",function(){
	var rand=Math.floor(Math.random()*100);
	
	for (var i = 0; i < rand; i++) {
		var elem=document.createElement("div");
		randTop=Math.floor(Math.random()*h)
		randLeft=Math.floor(Math.random()*w)
		elem.className="elem";
		elem.style.top=randTop+"px";
		elem.style.left=randLeft+"px";
		document.body.appendChild(elem)
	}
})
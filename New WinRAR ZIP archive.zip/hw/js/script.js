var btn=document.querySelector("button");
// btn.addEventListener("click",function(){
// 	console.log("Test")
// });

function ShowModal(){
	console.log(document.querySelectorAll(".select:empty"))
	}